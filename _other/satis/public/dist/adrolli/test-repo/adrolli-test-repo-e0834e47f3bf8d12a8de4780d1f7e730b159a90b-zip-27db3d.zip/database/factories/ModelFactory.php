<?php

namespace Adrolli\TestRepo\Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/*
class ModelFactory extends Factory
{
    protected $model = YourModel::class;

    public function definition()
    {
        return [

        ];
    }
}
*/
