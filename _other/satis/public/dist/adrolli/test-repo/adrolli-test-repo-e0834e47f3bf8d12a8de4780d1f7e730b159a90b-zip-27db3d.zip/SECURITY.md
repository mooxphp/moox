# Security Policy

## Supported Versions

We maintain the current version of `test-repo` actively. 

Do not expect security fixes for older versions.

## Reporting a Vulnerability

If you find any security-related bug, please report it to alf@drollinger.info. 

Please do not use Github issues, to give us enough time to review and fix the issue, before others can use it, to do stupid things.
