<?php

declare(strict_types=1);

namespace Adrolli\TestRepo\Components\Livewire;

use Illuminate\Contracts\View\View;
use Adrolli\TestRepo\Components\LivewireComponent;

class FirstLivewireComponent extends LivewireComponent
{
    /** @var array */
    protected static $assets = ['example'];

    /** @var string|null */
    public string $first_var = "";

    public function mount(): void
    {
        // mount
    }

    public function render(): View
    {
        return view('test-repo::components.livewire.first-livewire-component');
    }
}
