<?php

declare(strict_types=1);

namespace Adrolli\TestRepo\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Adrolli\TestRepo\TestRepo
 */
class TestRepo extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return 'test-repo';
    }
}
