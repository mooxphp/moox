<?php

declare(strict_types=1);

namespace Adrolli\TestRepo;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Str;
use Illuminate\View\Compilers\BladeCompiler;
use Livewire\Livewire;
use Spatie\LaravelPackageTools\Package;
use Spatie\LaravelPackageTools\PackageServiceProvider;
use Adrolli\TestRepo\Commands\TestRepoCommand;
use Adrolli\TestRepo\Components\BladeComponent;
use Adrolli\TestRepo\Components\LivewireComponent;

class TestRepoServiceProvider extends PackageServiceProvider
{
    public function configurePackage(Package $package): void
    {
        $package
            ->name('test-repo')
            ->hasConfigFile()
            ->hasViews()
            ->hasTranslations()
            ->hasMigration('create_test-repo_table')
            ->hasCommand(TestRepoCommand::class);
    }

    public function boot()
    {
        $this->bootResources();
        $this->bootBladeComponents();
        $this->bootLivewireComponents();
        $this->bootDirectives();
    }

    private function bootResources(): void
    {
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'test-repo');
    }

    private function bootBladeComponents(): void
    {
        $this->callAfterResolving(BladeCompiler::class, function (BladeCompiler $blade) {
            $prefix = config('test-repo.prefix', '');
            $assets = config('test-repo.assets', []);

            /** @var BladeComponent $component */
            foreach (config('test-repo.components', []) as $alias => $component) {
                $blade->component($component, $alias, $prefix);

                $this->registerAssets($component, $assets);
            }
        });
    }

    private function bootLivewireComponents(): void
    {
        if (! class_exists(Livewire::class)) {
            return;
        }

        $prefix = config('test-repo.prefix', '');
        $assets = config('test-repo.assets', []);

        /** @var LivewireComponent $component */
        foreach (config('test-repo.livewire', []) as $alias => $component) {
            $alias = $prefix ? "$prefix-$alias" : $alias;

            Livewire::component($alias, $component);

            $this->registerAssets($component, $assets);
        }
    }

    private function registerAssets($component, array $assets): void
    {
        foreach ($component::assets() as $asset) {
            $files = (array) ($assets[$asset] ?? []);

            collect($files)->filter(function (string $file) {
                return Str::endsWith($file, '.css');
            })->each(function (string $style) {
                TestRepo::addStyle($style);
            });

            collect($files)->filter(function (string $file) {
                return Str::endsWith($file, '.js');
            })->each(function (string $script) {
                TestRepo::addScript($script);
            });
        }
    }

    private function bootDirectives(): void
    {
        Blade::directive('TestRepoStyles', function (string $expression) {
            return "<?php echo Adrolli\\TestRepo\\TestRepo::outputStyles($expression); ?>";
        });

        Blade::directive('TestRepoScripts', function (string $expression) {
            return "<?php echo Adrolli\\TestRepo\\TestRepo::outputScripts($expression); ?>";
        });
    }
}
