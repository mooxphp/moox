<?php

namespace Adrolli\TestRepo\Commands;

use Illuminate\Console\Command;

class TestRepoCommand extends Command
{
    public $signature = 'test-repo';

    public $description = 'My command';

    public function handle(): int
    {
        $this->comment('All done');

        return self::SUCCESS;
    }
}
