<div>
    <h1>Hello <b>TALL</b>UI</h1>
    <p>
        This is a simple Livewire component.
    </p>
</div>
