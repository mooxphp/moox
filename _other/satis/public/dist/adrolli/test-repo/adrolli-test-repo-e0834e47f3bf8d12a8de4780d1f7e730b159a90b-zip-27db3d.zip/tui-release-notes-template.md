# Release Notes

These are example release notes, please enter notable changes here:

![Dashboard](idontknowwhere/dashboard.png)

- First change, Github Issue #23
- Second change, Git Commit-Hash
- Third change, made by @adrolli
- Forth change, linked (here)[https://tallui.io]
